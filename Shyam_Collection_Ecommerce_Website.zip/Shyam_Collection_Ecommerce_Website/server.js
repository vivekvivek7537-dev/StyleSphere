require("dotenv").config();
const express = require("express");
const session = require("express-session");
const path = require("path");
const fs = require("fs");
const bcrypt = require("bcryptjs");
const Razorpay = require("razorpay");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = path.join(__dirname, "data");
const PRODUCTS_FILE = path.join(DATA_DIR, "products.json");
const ORDERS_FILE = path.join(DATA_DIR, "orders.json");

if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 24) {
  console.error("Set a strong SESSION_SECRET (at least 24 characters) in .env");
  process.exit(1);
}
if (!process.env.ADMIN_PASSWORD || process.env.ADMIN_PASSWORD.length < 12) {
  console.error("Set ADMIN_PASSWORD to at least 12 characters in .env");
  process.exit(1);
}

fs.mkdirSync(DATA_DIR, { recursive: true });
function readJson(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, "utf8")); } catch { return fallback; }
}
function writeJson(file, value) {
  fs.writeFileSync(file, JSON.stringify(value, null, 2));
}
if (!fs.existsSync(PRODUCTS_FILE)) writeJson(PRODUCTS_FILE, [
  { id: "p1", name: "Classic Everyday Tote", category: "Bags", price: 899, description: "A versatile everyday essential with a refined finish.", image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=900&q=80", active: true },
  { id: "p2", name: "Minimal Gold Accent Watch", category: "Accessories", price: 1499, description: "A timeless accessory for everyday styling.", image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=900&q=80", active: true },
  { id: "p3", name: "Premium Style Sneakers", category: "Footwear", price: 1899, description: "Comfort-led design with a clean modern silhouette.", image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=80", active: true }
]);
if (!fs.existsSync(ORDERS_FILE)) writeJson(ORDERS_FILE, []);

app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true }));
app.use(session({
  name: "shyam.sid",
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: false, maxAge: 8 * 60 * 60 * 1000 }
}));
app.use(express.static(path.join(__dirname, "public")));

const adminUser = process.env.ADMIN_USERNAME || "admin";
const adminPasswordHash = bcrypt.hashSync(process.env.ADMIN_PASSWORD, 12);
const razorpayReady = Boolean(
  process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET &&
  process.env.RAZORPAY_KEY_ID.startsWith("rzp_test_") &&
  !process.env.RAZORPAY_KEY_ID.endsWith("your_key_id")
);
const razorpay = razorpayReady ? new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET
}) : null;

function requireAdmin(req, res, next) {
  if (!req.session.admin) return res.status(401).json({ error: "Please sign in as admin." });
  next();
}
function cleanAddress(a) {
  const fields = ["name", "phone", "line1", "line2", "city", "state", "pincode", "landmark"];
  const out = {};
  for (const f of fields) out[f] = String(a?.[f] || "").trim().slice(0, 180);
  return out;
}
function validateAddress(a) {
  if (!a.name || !/^[6-9]\d{9}$/.test(a.phone) || !a.line1 || !a.city || !a.state || !/^\d{6}$/.test(a.pincode)) {
    return "Enter name, valid 10-digit mobile, street address, city, state and 6-digit PIN code.";
  }
  return null;
}

app.get("/api/products", (req, res) => {
  res.json(readJson(PRODUCTS_FILE, []).filter(p => p.active !== false));
});
app.get("/api/config", (req, res) => {
  res.json({ storeName: process.env.STORE_NAME || "Shyam Collection", razorpayReady, payments: ["UPI", "COD"], delivery: "All Over India" });
});

app.post("/api/orders", async (req, res) => {
  try {
    const { items, address, paymentMethod } = req.body || {};
    if (!Array.isArray(items) || !items.length) return res.status(400).json({ error: "Your cart is empty." });
    if (!["UPI", "COD"].includes(paymentMethod)) return res.status(400).json({ error: "Choose UPI or Cash on Delivery." });
    const addr = cleanAddress(address);
    const addressError = validateAddress(addr);
    if (addressError) return res.status(400).json({ error: addressError });

    const products = readJson(PRODUCTS_FILE, []);
    const normalized = [];
    for (const item of items) {
      const product = products.find(p => p.id === String(item.id) && p.active !== false);
      const qty = Math.max(1, Math.min(10, Number(item.quantity) || 1));
      if (!product) return res.status(400).json({ error: "A product in your cart is unavailable." });
      normalized.push({ id: product.id, name: product.name, price: Number(product.price), quantity: qty });
    }
    const total = normalized.reduce((sum, p) => sum + p.price * p.quantity, 0);
    const orderId = "SC" + Date.now();
    const order = { id: orderId, items: normalized, address: addr, paymentMethod, total, status: "Pending", paymentStatus: paymentMethod === "COD" ? "Pay on delivery" : "Payment pending", createdAt: new Date().toISOString() };

    if (paymentMethod === "UPI") {
      if (!razorpay) return res.status(503).json({ error: "UPI checkout is not configured yet. Add Razorpay TEST API keys to .env." });
      const rpOrder = await razorpay.orders.create({ amount: total * 100, currency: "INR", receipt: orderId });
      order.razorpayOrderId = rpOrder.id;
      const orders = readJson(ORDERS_FILE, []);
      orders.unshift(order); writeJson(ORDERS_FILE, orders);
      return res.json({ orderId, razorpay: { key: process.env.RAZORPAY_KEY_ID, order_id: rpOrder.id, amount: rpOrder.amount, currency: rpOrder.currency }, message: "Test payment order created." });
    }
    const orders = readJson(ORDERS_FILE, []);
    orders.unshift(order); writeJson(ORDERS_FILE, orders);
    res.json({ orderId, message: "Your COD order has been placed." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Could not place order. Please try again." });
  }
});

app.post("/api/admin/login", (req, res) => {
  const { username, password } = req.body || {};
  if (username !== adminUser || !bcrypt.compareSync(String(password || ""), adminPasswordHash)) {
    return res.status(401).json({ error: "Incorrect username or password." });
  }
  req.session.admin = true;
  res.json({ ok: true });
});
app.post("/api/admin/logout", requireAdmin, (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});
app.get("/api/admin/me", (req, res) => res.json({ authenticated: Boolean(req.session.admin) }));
app.get("/api/admin/products", requireAdmin, (req, res) => res.json(readJson(PRODUCTS_FILE, [])));
app.post("/api/admin/products", requireAdmin, (req, res) => {
  const { name, category, price, description, image } = req.body || {};
  if (!String(name || "").trim() || !Number.isFinite(Number(price)) || Number(price) <= 0) return res.status(400).json({ error: "Product name and a valid price are required." });
  const products = readJson(PRODUCTS_FILE, []);
  const product = { id: "p" + Date.now(), name: String(name).trim(), category: String(category || "All Products").trim(), price: Math.round(Number(price)), description: String(description || "").trim(), image: String(image || "").trim(), active: true };
  products.unshift(product); writeJson(PRODUCTS_FILE, products); res.json(product);
});
app.delete("/api/admin/products/:id", requireAdmin, (req, res) => {
  const products = readJson(PRODUCTS_FILE, []);
  const p = products.find(x => x.id === req.params.id);
  if (!p) return res.status(404).json({ error: "Product not found." });
  p.active = false; writeJson(PRODUCTS_FILE, products); res.json({ ok: true });
});
app.get("/api/admin/orders", requireAdmin, (req, res) => res.json(readJson(ORDERS_FILE, [])));
app.patch("/api/admin/orders/:id", requireAdmin, (req, res) => {
  const allowed = ["Pending", "Confirmed", "Packed", "Shipped", "Delivered", "Cancelled"];
  const orders = readJson(ORDERS_FILE, []);
  const order = orders.find(o => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: "Order not found." });
  if (!allowed.includes(req.body.status)) return res.status(400).json({ error: "Invalid order status." });
  order.status = req.body.status; writeJson(ORDERS_FILE, orders); res.json(order);
});

app.get("/admin.html", (req, res) => res.sendFile(path.join(__dirname, "public", "admin.html")));
app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, "0.0.0.0", () => console.log(`Shyam Collection running at http://localhost:${PORT}`));
