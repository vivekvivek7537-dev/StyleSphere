const $ = s => document.querySelector(s);
const money = n => "₹" + Number(n).toLocaleString("en-IN");
const states = ["Andhra Pradesh","Arunachal Pradesh","Assam","Bihar","Chhattisgarh","Goa","Gujarat","Haryana","Himachal Pradesh","Jharkhand","Karnataka","Kerala","Madhya Pradesh","Maharashtra","Manipur","Meghalaya","Mizoram","Nagaland","Odisha","Punjab","Rajasthan","Sikkim","Tamil Nadu","Telangana","Tripura","Uttar Pradesh","Uttarakhand","West Bengal","Andaman and Nicobar Islands","Chandigarh","Dadra and Nagar Haveli and Daman and Diu","Delhi","Jammu and Kashmir","Ladakh","Lakshadweep","Puducherry"];
let products = [], cart = JSON.parse(localStorage.getItem("sc-cart") || "[]");
function toast(message){const t=$("#toast");t.textContent=message;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2600)}
function saveCart(){localStorage.setItem("sc-cart",JSON.stringify(cart));renderCart()}
function renderProducts(){
 const host=$("#products");$("#productCount").textContent=products.length+" pieces";
 host.innerHTML=products.length?products.map(p=>`<article class="product-card"><div class="product-image">${p.image?`<img src="${esc(p.image)}" alt="${esc(p.name)}" onerror="this.style.display='none'">`:`<div class="no-image">SHYAM</div>`}</div><div class="product-info"><span class="product-category">${esc(p.category||"Collection")}</span><h3>${esc(p.name)}</h3><p>${esc(p.description||"Thoughtfully selected for your everyday style.")}</p><div class="product-bottom"><span class="price">${money(p.price)}</span><button class="add-button" data-add="${esc(p.id)}">ADD TO BAG +</button></div></div></article>`).join(""):"<p class='muted'>Our collection is being updated. Please check back soon.</p>";
 host.querySelectorAll("[data-add]").forEach(b=>b.addEventListener("click",()=>{const p=products.find(x=>x.id===b.dataset.add);const row=cart.find(x=>x.id===p.id);if(row)row.quantity++;else cart.push({id:p.id,quantity:1});saveCart();toast("Added to your bag.")}));
}
function esc(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function renderCart(){
 $("#cartCount").textContent=cart.reduce((s,x)=>s+x.quantity,0);
 const host=$("#cartItems");let total=0;
 host.innerHTML=cart.length?cart.map(row=>{const p=products.find(x=>x.id===row.id);if(!p)return "";total+=p.price*row.quantity;return `<div class="cart-row"><div><strong>${esc(p.name)}</strong><small>${money(p.price)} each</small><div class="qty-controls"><button data-qty="${p.id}" data-delta="-1">−</button><span>${row.quantity}</span><button data-qty="${p.id}" data-delta="1">+</button></div></div><strong>${money(p.price*row.quantity)}</strong></div>`}).join(""):"<p class='muted'>Your bag is waiting for something lovely.</p>";
 $("#cartTotal").textContent=money(total);
 host.querySelectorAll("[data-qty]").forEach(b=>b.addEventListener("click",()=>{const r=cart.find(x=>x.id===b.dataset.qty);r.quantity+=Number(b.dataset.delta);if(r.quantity<=0)cart=cart.filter(x=>x!==r);saveCart()}));
}
function openCart(){$("#cartOverlay").classList.add("open")}function closeCart(){$("#cartOverlay").classList.remove("open")}
$("#openCart").onclick=openCart;$("#closeCart").onclick=closeCart;$("#cartOverlay").addEventListener("click",e=>{if(e.target.id==="cartOverlay")closeCart()});
$("#checkoutBtn").onclick=()=>{if(!cart.length)return toast("Your bag is empty.");closeCart();$("#checkoutOverlay").classList.add("open")};
$("#closeCheckout").onclick=()=>$("#checkoutOverlay").classList.remove("open");
$("#checkoutOverlay").addEventListener("click",e=>{if(e.target.id==="checkoutOverlay")$("#checkoutOverlay").classList.remove("open")});
const stateSelect=$('select[name="state"]');states.forEach(s=>{const o=document.createElement("option");o.value=s;o.textContent=s;stateSelect.append(o)});
$("#checkoutForm").addEventListener("submit",async e=>{
 e.preventDefault();const btn=$("#placeOrder"),err=$("#checkoutError");err.textContent="";
 const data=Object.fromEntries(new FormData(e.target).entries());const paymentMethod=data.paymentMethod;delete data.paymentMethod;
 if(!/^[6-9]\d{9}$/.test(data.phone)||!/^\d{6}$/.test(data.pincode)){err.textContent="Please enter a valid Indian mobile number and 6-digit PIN code.";return}
 btn.disabled=true;btn.textContent="PLEASE WAIT…";
 try{
  const res=await fetch("/api/orders",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({items:cart,address:data,paymentMethod})});
  const result=await res.json();if(!res.ok)throw new Error(result.error||"Could not place order.");
  if(paymentMethod==="UPI"){
   if(!window.Razorpay)throw new Error("Razorpay checkout did not load. Check your internet connection.");
   const checkout=new Razorpay({key:result.razorpay.key,order_id:result.razorpay.order_id,amount:result.razorpay.amount,currency:"INR",name:"Shyam Collection",description:"Order "+result.orderId,prefill:{name:data.name,contact:data.phone},theme:{color:"#b18a45"},handler:function(){cart=[];saveCart();$("#checkoutOverlay").classList.remove("open");e.target.reset();toast("Payment submitted. Order ID: "+result.orderId)}});
   checkout.on("payment.failed",()=>toast("Payment was not completed. Please retry."));
   checkout.open();
  }else{cart=[];saveCart();$("#checkoutOverlay").classList.remove("open");e.target.reset();toast("Order placed! Your order ID is "+result.orderId)}
 }catch(ex){err.textContent=ex.message}
 finally{btn.disabled=false;btn.textContent="PLACE ORDER"}
});
async function init(){try{const r=await fetch("/api/products");products=await r.json();renderProducts();renderCart()}catch{$("#products").innerHTML="<p class='error'>Could not load products. Please refresh.</p>"}}
$("#year").textContent=new Date().getFullYear();init();
