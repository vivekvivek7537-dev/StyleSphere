# Shyam Collection — Luxury E-commerce Starter

A responsive white-and-gold storefront with a basic admin panel, product management, order management, India-wide address form, UPI checkout integration through Razorpay (test mode), and Cash on Delivery.

## Requirements
- Node.js 18 or newer
- Internet connection for Google Fonts, product image URLs and Razorpay Checkout
- Razorpay TEST API keys for online checkout testing

## Run locally
1. Extract `Shyam_Collection_Ecommerce_Website.zip`.
2. Open a terminal in the extracted project folder.
3. Install packages:
   ```bash
   npm install
   ```
4. Copy `.env.example` to `.env`.
   - Windows: `copy .env.example .env`
   - macOS/Linux/Termux: `cp .env.example .env`
5. Edit `.env`. Set a long random `SESSION_SECRET` and a strong `ADMIN_PASSWORD` (at least 12 characters). Add your Razorpay TEST key ID and secret.
6. Start:
   ```bash
   npm start
   ```
7. Open:
   - Storefront: http://localhost:3000
   - Admin: http://localhost:3000/admin.html

Default admin username is `admin` unless changed in `.env`. Use the password you set in `.env`.

## Payments
- COD orders are stored locally.
- UPI uses Razorpay Orders API and Razorpay Checkout. This starter intentionally accepts only TEST keys (`rzp_test_...`).
- A production launch needs server-side Razorpay signature verification, payment webhooks, HTTPS, persistent database, secure production session store, rate limiting, backups, privacy/terms/refund policies, and real courier/PIN-code serviceability integration. Do not accept live payments until these are implemented and tested.
- Payment success UI is not a substitute for server-side verification. The order remains payment-pending until you add verification.

## Delivery
The address form accepts Indian states/UTs and six-digit PIN codes across India. This is address capture, not a guarantee that every PIN code is serviceable. Connect a courier/shipping provider to validate serviceability and calculate shipping charges before launch.

## Data
Products and orders are stored in JSON files in `data/` for easy local testing. Back up these files. This is a starter project, not a production-ready marketplace.
